import { Component } from '@angular/core';
import { Router,NavigationExtras } from '@angular/router';
import * as $ from "jquery";
import { Console } from '@angular/core/src/console';
import { concat } from 'rxjs/operator/concat';
@Component ({
   selector: 'my-app',
   //template: 'Products',
   templateUrl: './product.component.html',
   styleUrls: ['./product.component.css']
})
export   class   Appproduct  {
  designProposalVal;
  designEffProposalVal;
  buildProposalVal;
  buildEffProposalVal;
  testProposalVal;
  testEffProposalVal;
  deployProposalVal;
  deployEffProposalVal;
  designPercent=15;
  buildPercent=30;
  testPercent=20;
  deployPercent=15;
  designMandays;
  buildMandays;
  testMandays;
  deployMandays;
  designTotWorkers;
  buildTotWorkers;
  testTotWorkers;
  deployTotWorkers;
  mandays : any;
  totWorkers;
  startDate : any;
  endDate : any;
  timePeriod : any;
  isResourceFetched=true;
  crName = "";
  crNumber = "";
  component = "";
  skill = "";
  application = "";
  compId;
  compVal;
  appId;
  appVal;
  skillId;
  skillVal;
  boj;
  bos;
  bsj;
  bsa;
  dod;
  teote;
  tot;
onFindIA(){
  console.log('mandays '+this.mandays);
  console.log('startDate'+this.startDate);
  console.log('endDate'+this.endDate);
  let sdate = new Date(this.startDate);
  let edate = new Date(this.endDate);

  // let timeDiff = Math.abs(edate.getTime()-sdate.getTime());
  // let timePeriod = Math.ceil(timeDiff/(1000*3600*24));
  this.timePeriod=edate.getDate()-sdate.getDate();
  this.totWorkers= Math.ceil(this.mandays/this.timePeriod);
  console.log('timePeriod'+this.timePeriod);
  console.log('totWorkers'+this.totWorkers);
  this.designMandays=(this.mandays*this.designPercent)/100;
  this.buildMandays=(this.mandays*this.buildPercent)/100;
  this.testMandays=(this.mandays*this.testPercent)/100;
  this.deployMandays=(this.mandays*this.deployPercent)/100;
  this.designTotWorkers=this.designMandays/this.timePeriod;
  this.buildTotWorkers=this.buildMandays/this.timePeriod;
  this.testTotWorkers=this.testMandays/this.timePeriod;
  this.deployTotWorkers=this.deployMandays/this.timePeriod;
  console.log('design mandays '+this.designTotWorkers);
  console.log('build mandays '+this.buildTotWorkers);
  console.log('test mandays '+this.testTotWorkers);
  console.log('deploy mandays '+this.deployTotWorkers);
  this.designProposal(this.designTotWorkers);
  this.buildProposal(this.buildTotWorkers);
  this.testProposal(this.testTotWorkers);
  this.deployProposal(this.deployTotWorkers);
}
deployProposal(deployWorkers:number){

  console.log('inside build Proposal with design workers '+deployWorkers);
  let tot = deployWorkers;
  let ase = 2.5, se =3, sse= 3.5, temp = tot;
  let ase_req=0, se_req=0, sse_req=0;
  while(tot>0){
    if(temp==tot){
    se_req=se_req+1;
    tot=tot-3;
    
    }
    else{
      if(tot>=3){
        se_req=se_req+1;
      tot=tot-3;
      
      }
      
    }
    if(!(tot<=0)){
      
      {ase_req=ase_req+1;
      tot=tot-2.5;
      
      }
    }
    if(!(tot<=0)){
      if(tot>=3.5){
      sse_req=sse_req+1;
      
      tot=tot-3.5;
      }
    }
  }
  
  this.deployProposalVal="ASE("+ase_req+"),SE("+se_req+"),SSE("+sse_req+")";
  console.log(this.buildProposalVal);
  let sse_ereq=Math.round(sse_req*20/100);
  let ase_ereq = Math.round(((sse_req*0.8*0.5*sse)/ase)+ase_req);
  let se_ereq = Math.round(((sse_req*0.8*0.5*sse)/se)+se_req);
  this.deployEffProposalVal="ASE("+ase_ereq+"),SE("+se_ereq+"),SSE("+sse_ereq+")";
  console.log(this.buildEffProposalVal);
}
testProposal(buildWorkers:number){
  console.log('inside build Proposal with design workers '+buildWorkers);
  let tot = buildWorkers;
  let ase = 1.5, se =2, sse= 2.5, temp = tot;
  let ase_req=0, se_req=0, sse_req=0;
  while(tot>0){
    if(temp==tot){
    se_req=se_req+1;
    tot=tot-2;
    
    }
    else{
      if(tot>=2){
        se_req=se_req+1;
      tot=tot-2;
      
      }
      
    }
    if(!(tot<=0)){
      
      {ase_req=ase_req+1;
      tot=tot-1.5;
      
      }
    }
    if(!(tot<=0)){
      if(tot>=2.5){
      sse_req=sse_req+1;
      
      tot=tot-2.5;
      }
    }
  }
  
  this.testProposalVal="ASE("+ase_req+"),SE("+se_req+"),SSE("+sse_req+")";
  console.log(this.buildProposalVal);
  let sse_ereq=Math.round(sse_req*20/100);
  let ase_ereq = Math.round(((sse_req*0.8*0.5*sse)/ase)+ase_req);
  let se_ereq = Math.round(((sse_req*0.8*0.5*sse)/se)+se_req);
  this.testEffProposalVal="ASE("+ase_ereq+"),SE("+se_ereq+"),SSE("+sse_ereq+")";
  console.log(this.buildEffProposalVal);
}
buildProposal(buildWorkers:number){
  console.log('inside build Proposal with design workers '+buildWorkers);
  let tot = buildWorkers;
  let ase = 1.5, se =2, sse= 2.5, temp = tot;
  let ase_req=0, se_req=0, sse_req=0;
  while(tot>0){
    if(temp==tot){
    se_req=se_req+1;
    tot=tot-2;
    
    }
    else{
      if(tot>=2){
        se_req=se_req+1;
      tot=tot-2;
      
      }
      
    }
    if(!(tot<=0)){
      
      {ase_req=ase_req+1;
      tot=tot-1.5;
      
      }
    }
    if(!(tot<=0)){
      if(tot>=2.5){
      sse_req=sse_req+1;
      
      tot=tot-2.5;
      }
    }
  }
  
  this.buildProposalVal="ASE("+ase_req+"),SE("+se_req+"),SSE("+sse_req+")";
  console.log(this.buildProposalVal);
  let sse_ereq=Math.round(sse_req*20/100);
  let ase_ereq = Math.round(((sse_req*0.8*0.5*sse)/ase)+ase_req);
  let se_ereq = Math.round(((sse_req*0.8*0.5*sse)/se)+se_req);
  this.buildEffProposalVal="ASE("+ase_ereq+"),SE("+se_ereq+"),SSE("+sse_ereq+")";
  console.log(this.buildEffProposalVal);
}
designProposal(designWorkers:number){
console.log('inside design Proposal with design workers '+designWorkers);
let propAM = Math.round(designWorkers/3);
this.designProposalVal = "AM("+propAM+")";
console.log(this.designProposalVal);
let s75 = propAM*75/100;
let t25 = propAM*25/100;
let truncVal = s75-Math.trunc(s75);
//this.designEffProposalVal = (s75-truncVal)+"AM,"+((t25+truncVal)*2)+"TL";
this.designEffProposalVal = "AM("+(s75-truncVal)+"),TL("+((t25+truncVal)*2)+")";
console.log(this.designEffProposalVal);
//document.getElementById('designProp').innerHTML = this.designProposalVal;
}
hello(){
  console.log('hello');
}
  onClickDate(){
    console.log('onClickDate');
    $("#datetimepicker1").datetimepicker();
  }
  onBlurMethod(){
    console.log("onblur");
    if(this.crNumber=="150123"){
      this.crName = "Change request to add a new upstream system";
  }
  else if(this.crNumber=="150234"){
    this.crName = "Weblogic version upgrade";
  }
  else if(this.crNumber=="150345"){
    this.crName = "Security Vulnerability - Struts version upgrade";
  }
  else{
    this.crName = "Fix GUI open defects";
  }
  
  }
  fetchRes(){
    console.log("fetchRes-start");
    this.compId=document.getElementById("comp");
    this.compVal = this.compId.options[this.compId.selectedIndex].text;
    this.appId=document.getElementById("app");
    this.appVal = this.appId.options[this.appId.selectedIndex].text;
    this.skillId=document.getElementById("skill");
    this.skillVal = this.skillId.options[this.skillId.selectedIndex].text;
    console.log(this.compVal);
    if(this.compVal=="Build" && this.appVal=="OPOM" && this.skillVal=="Java"){
      this.isResourceFetched=false;
      this.boj=true;
      this.bos=false;
      this.bsj=false;
      this.bsa=false;
      this.teote=false;
      this.dod=false;
      this.tot=false;
      
    }
    else  if(this.compVal=="Build" && this.appVal=="OPOM" && this.skillVal=="Salesforce"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=true;
      this.bsj=false;
      this.bsa=false;
      this.teote=false;
      this.dod=false;
      this.tot=false;
      
    }
    else  if(this.compVal=="Build" && this.appVal=="SOS" && this.skillVal=="Java"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=false;
      this.bsj=true;
      this.bsa=false;
      this.teote=false;
      this.dod=false;
      this.tot=false;
      
    }
    else  if(this.compVal=="Build" && this.appVal=="SOS" && this.skillVal=="Angular"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=false;
      this.bsj=false;
      this.bsa=true;
      this.teote=false;
      this.dod=false;
      this.tot=false;
      
    }
    else  if(this.compVal=="Test" && this.appVal=="OPOM" && this.skillVal=="Test"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=false;
      this.bsj=false;
      this.bsa=false;
      this.teote=true;
      this.dod=false;
      this.tot=false;
      
    }
    else  if(this.compVal=="Design" && this.appVal=="OPOM" && this.skillVal=="Design"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=false;
      this.bsj=false;
      this.bsa=false;
      this.dod=true;
      this.teote=false;
      
      this.tot=false;
      
    }
    else  if(this.compVal=="Deploy" && this.appVal=="OPOM" && this.skillVal=="Deploy"){
      this.isResourceFetched=false;
      this.boj=false;
      this.bos=false;
      this.bsj=false;
      this.bsa=false;
      this.teote=false;
      this.dod=false;
      this.tot=true;
      
    }
    else{
      this.boj=false;
      this.bos=false;
      this.bsj=false;
      this.bsa=false;
      this.isResourceFetched=true;
    }
    console.log("fetchRes-end");
  }
  isCollapsed;
  isChild=true;
  toShow=false;
   fieldArray = [];
   testArray=[];
   designArray=[];
   taArray=[];
   countVal;
   newAttribute: string ;
   i : string;
   j : number = 0;
   jDesign : number =0;
   jDeploy : number =0;
   jTest : number =0;
   isDisabled1; isDisabled2 ; isDisabled3 ; isDisabled4 ; isDisabled5 ; isDisabled6 ; isDisabled7 ;
   isDisabled8 ; isDisabled9 ; isDisabled10 ; isDisabled11 ;isDisabled12 ;
   val  ;
   index: number;
   ele : any;
  /*addFieldValue() {
    this.fieldArray.push(this.newAttribute)
    this.newAttribute = {};
  }*/

/*deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
    this.isDisabled=false;
}
*/
  
  //  isUserClicked=true;

  public constructor(private router: Router) { }
  public onTap() {
    console.log("ontap");
    let navigationExtras: NavigationExtras = {
        queryParams: {
            "fieldArray": this.fieldArray
        }
    };
    this.router.navigate(["/Suser"], navigationExtras);
}

  twoCondition(){
    if(this.isCollapsed==true && this.isChild == true)
return true;
else 
return false;
    }

  
    toUpdate(event : any){
      console.log(event);
      console.log("j");
      console.log(event.lastVal);
      this.j = event.lastVal;
    }
  onUpdateIA(){
    console.log('inside update ia');
    console.log(this.j);
    console.log(document.getElementById("ia_build").innerHTML=String(this.j));
  }
  e1Add(event:any) {
   // this.isDisabled=true;
   //console.log(document.getElementById("hello").innerHTML);
   //this.isCollapsed = true;
  //  let currId = event.target.id;
  //  console.log("currId"+currId);
  //  event.target.id = currId.replace("Add","Remove");
  //  console.log(event.target.id);
  //  let y=event.target.parentElement.parentElement.parentElement.querySelector('.mail');
  //  let x=y.innerHTML;
  
  //  this.newAttribute=x;
  //   this.fieldArray.push(this.newAttribute)
    let a = event.target.parentElement.parentElement.parentElement.querySelector('.comp').innerHTML;
    console.log(a);
    if(a=="Build"){
      let y=event.target.parentElement.parentElement.parentElement.querySelector('.mail');
      let x=y.innerHTML;
      
      this.newAttribute=x;
       this.fieldArray.push(this.newAttribute)
      console.log("start if");
      //this.isCollapsed = true;
     if(document.getElementById("ia_build").innerHTML!=null){
         this.i = document.getElementById("ia_build").innerHTML;
        console.log(this.i);
        this.j = Number(this.i)+1;
        console.log(this.j);
        document.getElementById("ia_build").innerHTML=String(this.j);
        console.log(document.getElementById("ia_build").innerHTML);
      }
     // console.log(i);
      //i=i+1;
      console.log("end if");
    }
    if(a=="Design"){
      console.log("start if design");
      let y=event.target.parentElement.parentElement.parentElement.querySelector('.mail');
      let x=y.innerHTML;
      this.newAttribute=x;
       this.designArray.push(this.newAttribute)
      //this.isCollapsed = true;
     if(document.getElementById("ia_design").innerHTML!=null){
         this.i = document.getElementById("ia_design").innerHTML;
        console.log(this.i);
        this.jDesign = Number(this.i)+1;
        console.log(this.jDesign);
        document.getElementById("ia_design").innerHTML=String(this.jDesign);
        console.log(document.getElementById("ia_design").innerHTML);
      }

      
     // console.log(i);
      //i=i+1;
      console.log("end if");
    }

    if(a=="Deploy"){
      console.log("start if deploy");
      let y=event.target.parentElement.parentElement.parentElement.querySelector('.mail');
      let x=y.innerHTML;
      
      this.newAttribute=x;
       this.taArray.push(this.newAttribute)
     if(document.getElementById("ia_deploy").innerHTML!=null){
         this.i = document.getElementById("ia_deploy").innerHTML;
        console.log(this.i);
        this.jDeploy = Number(this.i)+1;
        console.log(this.jDeploy);
        document.getElementById("ia_deploy").innerHTML=String(this.jDeploy);
        console.log(document.getElementById("ia_deploy").innerHTML);
      }

      
     // console.log(i);
      //i=i+1;
      console.log("end if");
    }
    if(a=="Test"){
      console.log("start if test");
      let y=event.target.parentElement.parentElement.parentElement.querySelector('.mail');
      let x=y.innerHTML;
      
      this.newAttribute=x;
       this.testArray.push(this.newAttribute)
     if(document.getElementById("ia_test").innerHTML!=null){
         this.i = document.getElementById("ia_test").innerHTML;
        console.log(this.i);
        this.jTest = Number(this.i)+1;
        console.log(this.jTest);
        document.getElementById("ia_test").innerHTML=String(this.jTest);
        console.log(document.getElementById("ia_test").innerHTML);
      }

      
     // console.log(i);
      //i=i+1;
      console.log("end if");
    }

    }
    e1Remove(event:any){
     // this.isDisabled=false;
      
      let a = event.target.parentElement.parentElement.parentElement.querySelector('.comp').innerHTML;
      console.log(a);
      if(a=="Build"){
        console.log("start if");
        this.val = event.target.parentElement.parentElement.parentElement.querySelector('.mail').innerHTML;
        this.index =this.fieldArray.indexOf(this.val);
       this.fieldArray.splice(this.index,1);
       if(document.getElementById("ia_build").innerHTML!=null){
        this.i = document.getElementById("ia_build").innerHTML;
          console.log(this.i);
          this.j = Number(this.i)-1;
          console.log(this.j);
          document.getElementById("ia_build").innerHTML=String(this.j);
          console.log(document.getElementById("ia_build").innerHTML);
        }
       // console.log(i);
        //i=i+1;
        console.log("end if");
      }
      if(a=="Design"){
        console.log("start if");
        this.val = event.target.parentElement.parentElement.parentElement.querySelector('.mail').innerHTML;
        this.index =this.designArray.indexOf(this.val);
       this.designArray.splice(this.index,1);
       if(document.getElementById("ia_design").innerHTML!=null){
        this.i = document.getElementById("ia_design").innerHTML;
          console.log(this.i);
          this.jDesign = Number(this.i)-1;
          console.log(this.jDesign);
          document.getElementById("ia_design").innerHTML=String(this.jDesign);
          console.log(document.getElementById("ia_design").innerHTML);
        }
       // console.log(i);
        //i=i+1;
        console.log("end if");
      }
      if(a=="Test"){
        console.log("start if");
        this.val = event.target.parentElement.parentElement.parentElement.querySelector('.mail').innerHTML;
        this.index =this.testArray.indexOf(this.val);
       this.testArray.splice(this.index,1);
       if(document.getElementById("ia_test").innerHTML!=null){
        this.i = document.getElementById("ia_test").innerHTML;
          console.log(this.i);
          this.jTest = Number(this.i)-1;
          console.log(this.jTest);
          document.getElementById("ia_test").innerHTML=String(this.jTest);
          console.log(document.getElementById("ia_test").innerHTML);
        }
       // console.log(i);
        //i=i+1;
        console.log("end if");
      }
      if(a=="Deploy"){
        console.log("start if");
        this.val = event.target.parentElement.parentElement.parentElement.querySelector('.mail').innerHTML;
        this.index =this.taArray.indexOf(this.val);
       this.taArray.splice(this.index,1);
       if(document.getElementById("ia_deploy").innerHTML!=null){
        this.i = document.getElementById("ia_deploy").innerHTML;
          console.log(this.i);
          this.jDeploy = Number(this.i)-1;
          console.log(this.jDeploy);
          document.getElementById("ia_deploy").innerHTML=String(this.jDeploy);
          console.log(document.getElementById("ia_deploy").innerHTML);
        }
       // console.log(i);
        //i=i+1;
        console.log("end if");
      }
    }

                       
  

}