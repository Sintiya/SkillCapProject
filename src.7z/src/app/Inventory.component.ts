import { Component } from '@angular/core';
import { Router }  from '@angular/router';
@Component ({
   selector: 'invent-app',
   /*template: `Inventory 
   <a class = "button" (click) = "onBack()">Back to Products</a>`*/
   templateUrl : './Inventory.component.html'
})
export class AppInventory  {
    data : {};
    user;
    pwd;
    x;
    isApprootRequired=false;
    constructor(private _router: Router){} 
    
       onBack(name:string,pwd:string): void { 
        //setTimeout(() => this._router.navigate(['/Product']),5000);  
        
      /*  this.user=(<HTMLInputElement>document.getElementById("user"));
        if(this.user!=null){
this.x=this.user.value;
        }
        //this.x= this.user.;
        console.log('x val'+this.x);*/
        if(name=="admin"&&pwd=="admin"){
       this._router.navigate(['/Product']); 
    }
       } 
}