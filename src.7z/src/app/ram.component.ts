import { Component } from '@angular/core';
import { Router }  from '@angular/router';
@Component ({
   selector: 'ram-app',
   /*template: `Inventory 
   <a class = "button" (click) = "onBack()">Back to Products</a>`*/
   templateUrl : './ram.component.html'
})
export class AppRam {
    
    private fieldArray: Array<any> = [];
    private newAttribute: any = {};

    constructor(private _router: Router){} 
  
    onBack(): void { 
        //setTimeout(() => this._router.navigate(['/Product']),5000);  
       // console.log(this.data);
       //this._router.navigate(['/Product']); 
       window.history.back();
       document.getElementById('findRes').click();
       } 
       addFieldValue() {
        this.fieldArray.push(this.newAttribute)
        this.newAttribute = {};
    }

    deleteFieldValue(index) {
        this.fieldArray.splice(index, 1);
    }
       
}