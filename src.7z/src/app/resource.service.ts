import { Injectable } from '@angular/core';

import { Http, Headers, RequestOptions } from '@angular/http';

//import {map} from 'rxjs/operators';
//import 'rxjs/add/operator/map';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class ResourceService {

  result: any;

  constructor(private _http: Http) { }

  getProducts() {
    console.log('inside getproducts');
    return this._http.get("/api/meanusers")
      .pipe(map(result => {
        console.log("1. " +result);
        console.log("JSON Str:"+JSON.stringify(result));
        this.result = JSON.parse(JSON.stringify(result));
        console.log('res : ' + this.result);
        console.log("json : "+ this.result._body);
      }));
  }

}