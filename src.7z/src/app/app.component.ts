import { Component } from '@angular/core';
import { Router }  from '@angular/router';

@Component ({
   selector: 'app-root',
   templateUrl: './app.component.html'
})
export class AppComponent  { 
  isLoggedIn = "true";
  isNavbarRequired=true;
  isASearch="true";
  setASearch(){
    this.isASearch="false";
    this.isLoggedIn="false";
  }
  setLoggedIn(){
    this.isLoggedIn="false";
    this.isASearch="false";
  }
  onClickA(){
if(this.isLoggedIn || this.isASearch)
  return true;
  else
  return false;

  }
}