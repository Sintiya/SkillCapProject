import { Component } from '@angular/core';
import { Router }  from '@angular/router';
@Component ({
   selector: 'action-app',
   /*template: `Inventory
   <a class = "button" (click) = "onBack()">Back to Products</a>`*/
   templateUrl : './action.component.html'
})
export class ActionComponent {
    isEditClicked=true;
    editVal = true;
    writeVal = false;
    disCR=false;
    disRes=false;
    advSer=false;
    crSer=false;
    crNum;
    private fieldArray: Array<any> = [];
    private newAttribute: any = {};
    private buildfieldArray: Array<any> = [];
    private newBuildAttribute: any = {};
    private testfieldArray: Array<any> = [];
    private newTestAttribute: any = {};
    private deployfieldArray: Array<any> = [];
    private newDeployAttribute: any = {};
    onChangeEdit(){
        this.editVal=false;
        this.writeVal=true;
    }
    onEditRes(){
        this.isEditClicked=false;
            this.disCR=true;
            this.disRes=false;
            this.advSer=true;
    }
    onEditCR(){
        this.isEditClicked=false;
this.disRes=true;
this.disCR=false;
this.crSer=true;
    }
    
    isSearchClicked=false;
    skillId;
    skillVal;
    isSkillJava=false;
    isSkillAngular=false;
                isJavaSOSCombo=false;
    empId;
   empName;
    enterpriseId;
    levelId;
    levelVal;
    appId;
    appVal;
    isSkillSalesforce=false;
    isEmpId;
   
    searchRes(){
       
        console.log(this.empId);
        this.skillId=document.getElementById("asearch-skill");
        this.skillVal = this.skillId.options[this.skillId.selectedIndex].text;
        console.log(this.skillVal);
                               
        this.levelId=document.getElementById("asearch-level");
        this.levelVal = this.levelId.options[this.levelId.selectedIndex].text;
        console.log(this.levelVal);
        this.appId=document.getElementById("asearch-app");
        this.appVal = this.appId.options[this.appId.selectedIndex].text;
        console.log(this.appVal);
        if(this.skillVal=="Java" && this.appVal=="--Please Select--" && this.levelVal=="--Please Select--"){
            this.isSkillJava=true;
            this.isSkillAngular=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
            console.log(this.isSkillJava);
        }
                                else if(this.skillVal=="Java" && this.appVal=="SOS" && this.levelVal=="--Please Select--"){
                                                this.isJavaSOSCombo=true;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
            console.log(this.isSkillJava);
        }
        else  if(this.skillVal=="Angular" && this.appVal=="--Please Select--" && this.levelVal=="--Please Select--"){
            this.isSkillAngular=true;
            this.isSkillJava=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
            console.log(this.isSkillAngular);
        }
        else if(this.skillVal=="Salesforce" &&this.appVal=="--Please Select--" &&this.levelVal=="--Please Select--"){
            this.isSkillSalesforce=true;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
        }
        else if(this.empId == '10970912' && this.skillVal=="--Please Select--" &&this.appVal=="--Please Select--" &&this.levelVal=="--Please Select--"){
 
this.isSkillSalesforce=false;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isEmpId=true;
                                                this.isJavaSOSCombo=false;
 
        }
    }
    constructor(private _router: Router){}
    onBack(): void {
        //setTimeout(() => this._router.navigate(['/Product']),5000); 
       // console.log(this.data);
       //this._router.navigate(['/Product']);
       window.history.back();
       document.getElementById('findRes').click();
       }
       onSearch()
{
    this.isSearchClicked=true;
}   
onFetchCR(){
    if(this.crNum=='150123'){
console.log('inside fetch cr method');
    }

}
onDelete(event:any){
    let x=event.target.parentElement.parentElement.parentElement.removeChild(event.target.parentElement.parentElement);
    console.log('test'+x);
}
addFieldValue() {
    this.fieldArray.push(this.newAttribute)
    this.newAttribute = {};
}

deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
}
addBuildFieldValue() {
    this.buildfieldArray.push(this.newBuildAttribute)
    this.newBuildAttribute = {};
}

deleteBuildFieldValue(index) {
    this.buildfieldArray.splice(index, 1);
}
addTestFieldValue() {
    this.testfieldArray.push(this.newTestAttribute)
    this.newTestAttribute = {};
}

deleteTestFieldValue(index) {
    this.testfieldArray.splice(index, 1);
}
addDeployFieldValue() {
    this.deployfieldArray.push(this.newDeployAttribute)
    this.newDeployAttribute = {};
}

deleteDeployFieldValue(index) {
    this.deployfieldArray.splice(index, 1);
}
}