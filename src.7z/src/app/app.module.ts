import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FintTheme from 'fusioncharts/themes/fusioncharts.theme.fint';
import { FusionChartsModule } from 'angular4-fusioncharts';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { Appproduct } from './product.component';
import { AppInventory } from './Inventory.component';
import { AppSam } from './sam.component';
import { AppRam } from './ram.component';
import { AppSuser } from './selecteduser.component';
import { AdvanceSearch } from './advancesearch.component';
import { NavbarComponent } from './navbar.component';
import { RouterModule, Routes } from '@angular/router';
import {ResourceService} from './resource.service';
import {HttpModule} from '@angular/http';
import {ActionComponent} from './action.component';
import {VisualComponent} from './visual.component';


//FusionChartsModule.fcRoot(FusionCharts, Charts, FintTheme);

const appRoutes: Routes = [
   { path: 'Product', component: Appproduct },
   { path: 'Inventory', component: AppInventory },
   { path: 'Sam', component: AppSam },
   { path: 'Ram', component: AppRam },
   {path: 'Suser', component: AppSuser},
   {path: 'Asearch', component: AdvanceSearch},
   {path: 'Action', component: ActionComponent},
   {path: 'Visual', component: VisualComponent}
];

@NgModule ({
   imports: [ BrowserModule,
    FusionChartsModule.forRoot(FusionCharts,Charts),
    HttpModule,
    FormsModule,
   RouterModule.forRoot(appRoutes)],
   providers: [ResourceService],
   declarations: [ VisualComponent,ActionComponent,AppComponent,Appproduct,AppInventory,AppSam,AppRam,AppSuser,AdvanceSearch,NavbarComponent],
   bootstrap: [ AppComponent ]
})
export class AppModule { }