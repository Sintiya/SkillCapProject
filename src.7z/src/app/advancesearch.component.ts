import { Component } from '@angular/core';
import { Router }  from '@angular/router';
@Component ({
   selector: 'search-app',
   /*template: `Inventory
   <a class = "button" (click) = "onBack()">Back to Products</a>`*/
   templateUrl : './advancesearch.component.html'
})
export class AdvanceSearch {
    isSearchClicked=false;
    skillId;
    skillVal;
    isSkillJava=false;
    isSkillAngular=false;
                isJavaSOSCombo=false;
    empId;
   empName;
    enterpriseId;
    levelId;
    levelVal;
    appId;
    appVal;
    isSkillSalesforce=false;
    isEmpId;
   
    searchRes(){
       
        console.log(this.empId);
        this.skillId=document.getElementById("asearch-skill");
        this.skillVal = this.skillId.options[this.skillId.selectedIndex].text;
        console.log(this.skillVal);
                               
        this.levelId=document.getElementById("asearch-level");
        this.levelVal = this.levelId.options[this.levelId.selectedIndex].text;
        console.log(this.levelVal);
        this.appId=document.getElementById("asearch-app");
        this.appVal = this.appId.options[this.appId.selectedIndex].text;
        console.log(this.appVal);
        if(this.skillVal=="Java" && this.appVal=="--Please Select--" && this.levelVal=="--Please Select--"){
            this.isSkillJava=true;
            this.isSkillAngular=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
            console.log(this.isSkillJava);
        }
                                else if(this.skillVal=="Java" && this.appVal=="SOS" && this.levelVal=="--Please Select--"){
                                                this.isJavaSOSCombo=true;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
            console.log(this.isSkillJava);
        }
        else  if(this.skillVal=="Angular" && this.appVal=="--Please Select--" && this.levelVal=="--Please Select--"){
            this.isSkillAngular=true;
            this.isSkillJava=false;
            this.isSkillSalesforce=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
            console.log(this.isSkillAngular);
        }
        else if(this.skillVal=="Salesforce" &&this.appVal=="--Please Select--" &&this.levelVal=="--Please Select--"){
            this.isSkillSalesforce=true;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isEmpId=false;
                                                this.isJavaSOSCombo=false;
        }
        else if(this.empId == '10970912' && this.skillVal=="--Please Select--" &&this.appVal=="--Please Select--" &&this.levelVal=="--Please Select--"){
 
this.isSkillSalesforce=false;
            this.isSkillJava=false;
            this.isSkillAngular=false;
            this.isEmpId=true;
                                                this.isJavaSOSCombo=false;
 
        }
    }
    constructor(private _router: Router){}
    onBack(): void {
        //setTimeout(() => this._router.navigate(['/Product']),5000); 
       // console.log(this.data);
       //this._router.navigate(['/Product']);
       window.history.back();
       document.getElementById('findRes').click();
       }
       onSearch()
{
    this.isSearchClicked=true;
}   
}