import { Component } from '@angular/core';
import { Router }  from '@angular/router';

@Component ({
   selector: 'nav-bar',
   templateUrl: './navbar.component.html'
})
export class NavbarComponent  { 
  //isLoggedIn = true;
  //isSideMenuRequired
}