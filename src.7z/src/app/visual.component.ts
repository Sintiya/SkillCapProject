import { Component, NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { Http, Response } from '@angular/http';
@Component({
    selector:'visual-app',
    templateUrl : './visual.component.html'
})
export class VisualComponent{
    //Commenting to include the chart - no of resources rolled off in the specific month
/*
    id = 'chart1';
    width = 600;
    height = 400;
    type = 'column2d';
    dataFormat = 'json';
    dataSource;
    title = 'Graphical Rep';
    onBack(): void {
      
       window.history.back();
       document.getElementById('findRes').click();
       }
    constructor() {
        this.dataSource = {
            "chart": {
                "caption": "Skill Demand Trend",
                "subCaption": "Top 5 Skills in demand",
                "numbersuffix": "%",
                "theme": "fint"
            },
            "data": [
                {
                    "label": "Java",
                    "value": "58%"
                    },
                    {
                    "label": "Dot net",
                    "value": "45%"
                    },
                    {
                    "label": "PL/SQL",
                    "value": "36%"
                    },
                    {
                    "label": "SAP",
                    "value": "27%"
                    },
                    {
                    "label": "Angular",
                    "value": "10%"}
            ]
        }
    } */

    //new chart code - start
  
  dataSource;
  skill_select_id;
  skill_select_val;
  mon_select_id;
  mon_select_val;
  des_select_id;
  des_select_val;
  csvUrl: string = 'http://localhost:4200/../assets/sample.csv';  // URL to web API
  csvData: any[] = [];
  csvMonDes: any[] = [];
  //dataSource = "" ;
  onBack(): void {
    
     window.history.back();
     document.getElementById('findRes').click();
     }
  
  getDataSource(arr_rec) {
    console.log('inside getDataSource')
    let arr = arr_rec;
    var domObj2 = '';
    //var domObj1=''; 
    let countJun, countJul, countAug, countSep, countOct, countNov;

    let dom = {
      chart: {
        caption: this.skill_select_val,
        xAxisname: "Month",
        yAxisName: "Resources (In Number)",
        numberPrefix: "",
        baseFont: "Roboto",
        baseFontSize: "14",
        labelFontSize: "15",
        captionFontSize: "20",
        subCaptionFontSize: "16",
        paletteColors: "#2c7fb2,#6cc184,#fed466",
        bgColor: "#ffffff",
        legendShadow: "0",
        valueFontColor: "#ffffff",
        showXAxisLine: "1",
        xAxisLineColor: "#999999",
        divlineColor: "#999999",
        divLineIsDashed: "1",
        showAlternateHGridColor: "0",
        subcaptionFontBold: "0",
        subcaptionFontSize: "14",
        showHoverEffect: "1"
      },
      events: {
        'dataplotClick': function(evt, args) {
          this.showAlertTest(args);
//alert(args)
let arr = args.split(",");
let month = arr[0];
let des = arr[1];
let count = arr[2];
//alert(month)
//alert(month+" "+des+" "+count)
            // window.alert  = function(str){
            //     var arr = str.split(",");    
            //    // alert("[Example for the 'j-' prefix] \n" + arr[0] + " juice sales for the last year: " + arr[1]+" "+arr[2]);
            // };
            (<any>window).showAlert =  function(str){
              console.log(str);
                 var arr = str.split(",");    
                alert("[Example for the 'j-' prefix] \n" + arr[0] + " juice sales for the last year: " + arr[1]+" "+arr[2]);
               };
        }
    },
      categories: [{
        category: [{
          label: "Jun"
        }, {
          label: "Jul"
        }, {
          label: "Aug"
        }, {
          label: "Sep"
        }, {
          label: "Oct"
        }, {
          label: "Nov"
        }]
      }],
      dataset: []
    };



console.log(" arr len"+arr.length)
for(let x=0;x<arr.length;x++){
  console.log(arr[x])
}
    for (let i = 13; i > 4; i--) {
      let data = [];
      let clr="";
      let countJun=0, countJul=0, countAug=0, countSep=0, countOct=0, countNov=0;
      for (let j = 0; j < arr.length; j++) {
        console.log()
        let arr_spl = arr[j].split(" ");
        console.log("arr_spl "+arr_spl+" "+arr_spl[0]+" "+arr_spl[1])
        if (arr_spl[0] == 'Jun-18' && arr_spl[1] == i) {
          countJun = arr_spl[2];
          console.log("countJun "+countJun)
         
        }
        
         if (arr_spl[0] == 'Jul-18' && arr_spl[1] == i) {
          countJul = arr_spl[2];
          console.log("countJul "+countJul)
          
        }
       
         if (arr_spl[0] == 'Aug-18' && arr_spl[1] == i) {
          countAug = arr_spl[2];
          console.log("countAug "+countAug)
         
        }
        
         if (arr_spl[0] == 'Sep-18' && arr_spl[1] == i) {
          countSep = arr_spl[2];
          console.log("countSep "+countSep)
          
        }
      
         if (arr_spl[0] == 'Oct-18' && arr_spl[1] == i) {
          countOct = arr_spl[2];
          console.log("countOct "+countOct)
          
        }
       
         if (arr_spl[0] == 'Nov-18' && arr_spl[1] == i) {
          countNov = arr_spl[2];
          console.log("countNov "+countNov)
          
        }
        
        



      }

      if(i==13){
        clr = "#0075c2";
      }
      else if(i==12){
        clr="#FF0000";
      }
      else if(i==11){
        clr="#000000";
      }
      else if(i==10){
        clr="#808080";
      }
      else if(i==9){
        clr="#800000";
      }
      else if(i==8){
        clr="#bd59ed";
      }
      else if(i==7){
        clr="#ffd700";
      }
      else if(i==6){
        clr="#66ccff";
      }
      else if(i==5){
        clr="#ffdfe5";
      }
        //pushing data
        data.push({value : countJun,link : "j-showAlert-Jun,"+i+","+countJun});
        data.push({value : countJul,link : "j-showAlert-Jul,"+i+","+countJul});
        data.push({value : countAug,link : "j-showAlert-Aug,"+i+","+countAug});
        data.push({value : countSep,link : "j-alert-Sep,"+i+","+countSep});
        data.push({value : countOct,link : "j-showAlert-Oct,"+i+","+countOct});
        data.push({value : countNov,link : "j-showAlert-Nov,"+i+","+countNov});
      dom.dataset.push( {
        seriesname : " "+i+" ",
        color : clr,
        data : data
        
      });
      console.log("dom1 "+JSON.stringify(dom));
    }
   
    console.log("dom2 "+dom);
    this.dataSource = dom;
    //return this.dataSource;
  }

  constructor(private http: Http) {
    console.log("id "+document.getElementById('inp'));
  }
  
  showAlertTest(args){
    console.log("isnide showaltertest")
  }
  readCsvData() {
    this.http.get(this.csvUrl)
      .subscribe(
      data => this.extractData(data),
      err => this.handleError(err)
      );
  }
  readCsvDesMon() {
    this.http.get(this.csvUrl)
      .subscribe(
      data => this.extractRes(data),
      err => this.handleError(err)
      );
  }
  
extractRes(res: Response){
  this.des_select_id=document.getElementById('des_sel');
  this.des_select_val=this.des_select_id.options[this.des_select_id.selectedIndex].text;
  this.mon_select_id=document.getElementById('mon_sel');
  this.mon_select_val=this.mon_select_id.options[this.mon_select_id.selectedIndex].text;
  this.skill_select_id=document.getElementById('skill_select');
  // console.log("skill_select_id "+this.skill_select_id);
   this.skill_select_val = this.skill_select_id.options[this.skill_select_id.selectedIndex].text;
   
  console.log(this.des_select_val+" "+this.mon_select_val+" "+this.skill_select_val);

  let csvData = res['_body'] || '';
  let allTextLines = csvData.split(/\r\n|\n/);
  let headers = allTextLines[0].split(',');

  let lines = [];
  let resName = [];
  let roDate = [];
  let level = [];
  let skill = [];
let skillTextLines = [];
console.log("allTextLines.length "+allTextLines.length)
for(let i =0; i<allTextLines.length-1; i++){
let data1 = allTextLines[i].split(',');
console.log("data1[1] "+data1[1]);
//if(data1[1].indexOf("-")!=-1){
if(data1[1].substring(3,9)==this.mon_select_val&&data1[2]==this.des_select_val&&data1[3]==this.skill_select_val){
  skillTextLines.push(allTextLines[i]);
}
//}
}

console.log("skillTextLines.length "+skillTextLines.length)
for (let i = 0; i < skillTextLines.length; i++) {
console.log(skillTextLines[i])
}
  for (let i = 0; i < skillTextLines.length; i++) {

    let data = skillTextLines[i].split(',');
    //roDate.push(data[1]);
    //level.push(data[2]);


    if (data.length == headers.length) {
      let tarr = [];
      for (let j = 0; j < headers.length; j++) {
        tarr.push(data[j]);
      }
      lines.push(tarr);
    }

  }

  this.csvMonDes = lines;


}

onEditDate(){
  console.log('lenght'+this.csvMonDes.length);
  console.log(this.csvMonDes)
  for(let i=0;i<this.csvMonDes.length;i++){
    let temp = this.csvMonDes[i];
    console.log(this.csvMonDes[i][1]+"hi");
    //this.csvMonDes[i][1]=this.csvMonDes[i][1]+"hi";
    this.csvMonDes[i][1]=this.csvMonDes[i][1]+"<span class='glyphicon glyphicon-edit navtext'></span>"
   // temp[1]=temp[1]+"hi";
  }
}
  private extractData(res: Response) {
    // var e = document.getElementById("ddlViewBy");
    // console.log("e "+e)
    //var strUser = e.options[e.selectedIndex].value;
    //     let str = 'doit';
    // console.log(str.substring(1,3));
    // console.log("id "+document.getElementById('inp').innerText);
     this.skill_select_id=document.getElementById('skill_select');
    // console.log("skill_select_id "+this.skill_select_id);
     this.skill_select_val = this.skill_select_id.options[this.skill_select_id.selectedIndex].text;
     //console.log("skill_select_val "+this.skill_select_val);
    // console.log("skill choosed "+this.skill_select_val);

    let csvData = res['_body'] || '';
    let allTextLines = csvData.split(/\r\n|\n/);
    let headers = allTextLines[0].split(',');

    let lines = [];
    let resName = [];
    let roDate = [];
    let level = [];
    let skill = [];
let skillTextLines = [];
for(let i =0; i<allTextLines.length; i++){
  let data1 = allTextLines[i].split(',');
  if(data1[3]==this.skill_select_val){
    skillTextLines.push(allTextLines[i]);
  }
}

console.log("skillTextLines.length "+skillTextLines.length)
for (let i = 0; i < skillTextLines.length; i++) {
  console.log(skillTextLines[i])
}
    for (let i = 0; i < skillTextLines.length; i++) {

      let data = skillTextLines[i].split(',');
      roDate.push(data[1]);
      level.push(data[2]);


      if (data.length == headers.length) {
        let tarr = [];
        for (let j = 0; j < headers.length; j++) {
          tarr.push(data[j]);
        }
        lines.push(tarr);
      }

    }

    this.csvData = lines;
    //console.log("lines " + lines[1])
    console.log("lines.length "+lines.length)
    for (let i = 0; i < lines.length; i++) {
      console.log(lines[i])
    }
    console.log("roDate.length "+roDate.length)
    for (let i = 0; i < roDate.length; i++) {
      console.log(roDate[i])
    }
    console.log("level.length "+level.length)
    for (let i = 0; i < level.length; i++) {
      console.log(level[i])
    }
    
    
    let roDateSet = Array.from(new Set(roDate));
    console.log("roDateSet.length "+roDateSet.length)
    for (let i = 0; i < roDateSet.length; i++) {
     console.log(roDateSet[i].substring(3, 9))
    }
    let levelSet = Array.from(new Set(level));
    console.log("levelSet.length "+levelSet.length)
    for (let i = 0; i < levelSet.length; i++) {
     console.log(levelSet[i])
    }
    let num = 0;
    let arr = [];
    //console.log('roDateSet.length ' + roDateSet.length);
    //console.log('levelSet.length ' + levelSet.length)

    for (let i = 0; i < roDateSet.length ; i++) {
      for (let j = 0; j < levelSet.length ; j++) {
        for (let k = 0; k < lines.length; k++) {
          // console.log("test "+lines[k])
          let line_temp = lines[k] + '';
          //console.log("line_temp "+line_temp)
          let temp = line_temp.split(",")
        //  console.log("temp " + temp)
          let date = temp[1]
          // console.log('date ' + date)
          // console.log('roDateSet[i] ' + roDateSet[i])
          // console.log('temp[2] ' + temp[2])
          // console.log('levelSet[j] ' + levelSet[j])
          if ((roDateSet[i].substring(3, 9)) == (date.substring(3, 9)) && levelSet[j] == temp[2]) {
            num += 1;
           // console.log("num1 " + num)
          }
        }
       // console.log("num2 " + num);
        arr.push(roDateSet[i].substring(3, 9) + ' ' + levelSet[j] + ' ' + num);
        num = 0;

      }

    }
    console.log('final val')
    for (let i = 0; i < arr.length; i++) {
      console.log(arr[i]);

    }

    return this.getDataSource(arr);
  };

  private handleError(error: any) {
    // In a real world app, we might use a remote logging infrastructure
    // We'd also dig deeper into the error to get a better message
    let errMsg = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
    console.error(errMsg); // log to console instead
    return errMsg;
  }
  demoId: string = "ex1";


  //demoId = "ex1";

  //new chart code - end
}